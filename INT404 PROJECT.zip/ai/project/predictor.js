let vehicles = prompt("Dear User,Enter the number of vehicles");

if(vehicles==0)
alert("timer = 0 sec");
else if(vehicles>0 && vehicles<=3)
alert("timer = 10 sec");
else if(vehicles>3 && vehicles<=6)
alert("timer = 15 sec");
else if(vehicles>6 && vehicles<=9)
alert("timer = 20 sec");
else if(vehicles>9 && vehicles<=12)
alert("timer = 25 sec");
else if(vehicles>12 && vehicles<=15)
alert("timer = 30 sec");
else if(vehicles>15 && vehicles<=18)
alert("timer = 35 sec");
else if(vehicles>18 && vehicles<=21)
alert("timer = 40 sec");
else if(vehicles>21 && vehicles<=24)
alert("timer = 45 sec");
else if(vehicles>24 && vehicles<=27)
alert("timer = 50 sec");
else if(vehicles>27 && vehicles<=30)
alert("timer = 55 sec");
else if(vehicles>30 )
alert("timer = 60 sec");
else 
cout<<"error";