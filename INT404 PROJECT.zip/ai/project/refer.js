function refer()
{
    var email =document.myform.email.value;
     if(email==null || email=="")
     {
         alert("Please Enter Your Email ");
     }
     else
     {
         alert("We will Contact Your Friend As Soon As Possible");
     }
}